package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;

@RestController
public class Controller {
	@Autowired ProductService service;
	@GetMapping(value="/products",produces= {"application/json"})
	public List<Product> getall() {
		System.out.println("getAll called");
		return service.getall();
	}
	@PostMapping(value="/addProduct",consumes={"application/json"})
	public String addProduct(@RequestBody Product product) {
		System.out.println("addProduct called");
		return service.addProduct(product);
	}
	@GetMapping(value="/id/{id}",produces= {"application/json"})
	public Product getById(@PathVariable String id) {
		System.out.println("getById called");
		return service.getById(id);
	}
	@PostMapping(value="/products",consumes= {"application/json"})
	public String update(@RequestBody Product product) {
		System.out.println("update called");
		service.update(product);
		return "Product Updated";
	}
	@PostMapping(value="/delete/{id}")
	public String delete(@PathVariable String id) {
		System.out.println("delete called");
		service.delete(id);
		return "Product Deleted";
	}
	@GetMapping(value="/view/{from}/{to}")
	public List<Product> viewByRange(@PathVariable double from, @PathVariable double to ) {
		System.out.println("View By Range");
		
		return service.viewProductInRange(from, to);
	}
	
}
