package com.cg.dao;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.entity.Product;

public interface ProductDao extends JpaRepository<Product,String>{
	
//	public List<Product> getall();
//	public String addProduct(Product p);
//	public Product getById(Integer id);
//	public String update(Product p);
//	public String delete(Integer id);
	
	
	@Query("select p from Product p where p.productPrice>=?1 AND p.productPrice<=?2")
	public List<Product> viewProductInRange(Double from,Double to);
	
}
